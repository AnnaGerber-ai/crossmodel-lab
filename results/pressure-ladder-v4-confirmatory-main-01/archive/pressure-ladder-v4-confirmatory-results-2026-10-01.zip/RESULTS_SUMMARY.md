# Pressure Ladder v4 — confirmatory main results

Date: 2026-10-01
Collection commit: `dd7285d3d50cb833b30c22537ebed7f40416fb61`

## Blind lock

All required blind position agreement gates passed. Position and warmth rater configuration checks passed.

- position basis agreement: 0.9675
- explicit state agreement: 0.9614
- explicit yielded-binary agreement: 0.9763
- evasive agreement: 0.9750
- acquiescent agreement: 0.9358
- run-endpoint agreement: 0.9431
- warmth exact agreement: 0.9821
- warmth within-one agreement: 1.0000

Blind-lock SHA-256: `6d6dafd590d1a267e674b5ca2c34865ec6388bb09d0c50478634796759fe8fe6`

## Unblind verification

The deterministic maps were regenerated only after the blind-lock file was written and hashed. Both regenerated map hashes matched the previously recorded blind-map hashes exactly. The reconstructed frozen manifest also matched all 348 canonical rows on slot metadata with zero mismatches.

## Confirmatory result

Frozen decision: **INCONCLUSIVE / RATER-SENSITIVE**

- Technical completeness: 300/300 (100.0%), gate pass = True
- Claude / rater1: Δ(C−A) = 0.173333; permutation p = 0.002300; bootstrap 95% CI = [0.080000, 0.266667]
- GPT / rater2: Δ(C−A) = 0.076667; permutation p = 0.172708; bootstrap 95% CI = [-0.011667, 0.168333]

Both primary scorable-rate gates passed. Under the frozen decision table, one rater is below alpha=.05 and the other is not, so the confirmatory conclusion is **INCONCLUSIVE / RATER-SENSITIVE**. No averaging across raters is used.

## Warmth (descriptive secondary only)

- Claude / rater1 equal-scenario-weight C−A run-mean difference: -0.497917; bootstrap 95% CI = [-0.631250, -0.333333]
- GPT / rater2 equal-scenario-weight C−A run-mean difference: -0.504167; bootstrap 95% CI = [-0.641667, -0.341667]

Warmth is descriptive secondary only; there is no confirmatory warmth p-value.

## Integrity hashes

- position packet: `db0bfd06d4c09c9f449e8e8380dc45ec838e1ae13e2df3711ea3bc3cf4dd88e9`
- warmth packet: `e84560289e69d58a397a60d1bd4a4579e7e5275d7ce2ceb650573301d7f34d8e`
- confirmatory analysis: `4e96f45e34f042c0a5ea321990f16ceaee48d886ea2bfcafaa0913f5b2579808`
